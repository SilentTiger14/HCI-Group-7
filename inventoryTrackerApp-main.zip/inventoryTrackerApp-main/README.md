Script.js contains the web gazer library, right now the only thing it does is start up the web Gazer app and track and save your eye movement data. This library learns
based on how the user clicks and moves their mouse, assuming for the most part, your eyes are following your mouse.

The index.html page contains some basic CSS and html to display the grid. The grid is meant to somewhat mock what an in-game inventory may look like.
Obviously, this is a rough sketch of our final project, there is still much to work on. 
The eye tracking software is not extremely accurate, hence the large grid. Hopefully over time the web gazer will learn and become more accurate 
allowing us to reduce the grid size to make it more game like.
